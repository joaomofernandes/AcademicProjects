﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography.X509Certificates;

namespace DAL
{
    public class Employee
    {
        public int _employeeID;

        public string _first_Name;

        public string _last_Name;

        public int _LocationID;

        public string _Address;

        public string _PostalCode;

        public string _birthDate;

        public DateTime _addDate;

        public string _Notes;

        public Employee()
        {

        }
        public Employee(int employeeID)
        {

        }

        public int EmployeeID
        {
            get
            {
                return _employeeID;
            }
            set
            {
                _employeeID = value;
            }
        }
        public string FirstName
        {
            get
            {
                return _first_Name;
            }
            set
            {
                _first_Name = value;
            }
        }
        public string LastName
        {
            get
            {
                return _last_Name;
            }
            set
            {
                _last_Name = value;
            }
        }
        public int LocationID
        {
            get
            {
                return _LocationID;
            }
            set 
            {
                _LocationID = value;
            }
        }
        public string Address
        {

            get
            {
                return _Address;
            }
            set
            {
                _Address = value;
            }
        }

        public string PostalCode
        {
            get
            {
                return _PostalCode;
            }
            set
            {
                _PostalCode = value;
            }
        }

        public string BirthDate
        {
            get
            {
                return _birthDate;
            }
            set
            {
                _birthDate = value;
            }
        }

        public DateTime AddDate { get; set; }

        public string Notes
        {
            get
            {
                return _Notes;
            }
            set
            {
                _Notes = value;
            }
        }

        
    }
    public static class Employees
    {
        public static DataTable ListAll_Employees()
        {
            SqlConnection connection = new SqlConnection("Data Source = ASUS; Initial Catalog = CarRental; Integrated Security = True");
            string sql = "select EmployeeID, FirstName " +
           "+ ' ' + LastName as Name, Address + ' ' + PostalCode as Address, BirthDate, DateOfAdmission, Notes from Employee";
            SqlCommand command = new SqlCommand(sql, connection);
            connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(reader);

            return dataTable;
        }

        public static Employee ListAll_EmployeesByID(int employeeID)
        {
            SqlConnection connection = new SqlConnection("Data Source = ASUS; Initial Catalog = CarRental; Integrated Security = True");
            string sql = "select EmployeeID, FirstName, LastName, Address, PostalCode, BirthDate, DateOfAdmission, " +
                "Notes from Employee where EmployeeID = @EmployeeID";
            SqlCommand command = new SqlCommand(sql, connection);
            command.Parameters.Add(new SqlParameter("@EmployeeID", SqlDbType.Int, 0, "EmployeeID"));
            command.Parameters["@EmployeeID"].Value = employeeID;

            connection.Open();

            SqlDataReader reader = command.ExecuteReader();
            if (!reader.HasRows)
                return null;

            reader.Read();

            return new Employee
            {
                FirstName = reader["FirstName"].ToString(),
                LastName = reader["LastName"].ToString(),
                LocationID = int.Parse((string)reader["LocationID"]),
                Address = reader["Address"].ToString(),
                PostalCode = reader["PostalCode"].ToString(),
                BirthDate = reader["BirthDate"].ToString(),
                AddDate = DateTime.Parse(reader["DateOfAdmission"].ToString()),
                Notes = reader["Notes"].ToString()
            };

        }

        public static void AddEmployee(Employee employee)
        {
            SqlConnection connection = new SqlConnection("Data Source = ASUS; Initial Catalog = CarRental; Integrated Security = True");
            SqlCommand command = new SqlCommand("insertNewEmployee", connection);
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@FirstName", SqlDbType.NVarChar, 10));
            command.Parameters["@FirstName"].Value = employee.FirstName;

            command.Parameters.Add(new SqlParameter("@LastName", SqlDbType.NVarChar, 10));
            command.Parameters["@LastName"].Value = employee.LastName;

            command.Parameters.Add(new SqlParameter("@LocationID", SqlDbType.Int));
            command.Parameters["@LocationID"].Value = employee.LocationID;

            command.Parameters.Add(new SqlParameter("@Address", SqlDbType.NVarChar, 50));
            command.Parameters["@Address"].Value = employee.Address;

            command.Parameters.Add(new SqlParameter("@PostalCode", SqlDbType.NVarChar, 8));
            command.Parameters["@PostalCode"].Value = employee.PostalCode;

            command.Parameters.Add(new SqlParameter("@BirthDate", SqlDbType.Date));
            command.Parameters["@BirthDate"].Value = employee.BirthDate;

            command.Parameters.Add(new SqlParameter("@DateOfAdmission", SqlDbType.Date));
            command.Parameters["@DateOfAdmission"].Value = employee.AddDate;

            command.Parameters.Add(new SqlParameter("@Notes", SqlDbType.NText));
            command.Parameters["@Notes"].Value = employee.Notes;

            connection.Open();
            command.ExecuteNonQuery();
            connection.Close();
        }
        public static void updateEmployee(Employee employee)
        {
            SqlConnection connection = new SqlConnection("Data Source = ASUS; Initial Catalog = CarRental; Integrated Security = True");
            SqlCommand command = new SqlCommand("updateEmployee", connection);
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@EmployeeID", SqlDbType.Int));
            command.Parameters["@EmployeeID"].Value = employee.EmployeeID;

            command.Parameters.Add(new SqlParameter("@FirstName", SqlDbType.NVarChar, 10));
            command.Parameters["@FirstName"].Value = employee.FirstName;

            command.Parameters.Add(new SqlParameter("@LastName", SqlDbType.NVarChar, 10));
            command.Parameters["@LastName"].Value = employee.LastName;

            command.Parameters.Add(new SqlParameter("@LocationID", SqlDbType.Int));
            command.Parameters["@LocationID"].Value = employee.LocationID;

            command.Parameters.Add(new SqlParameter("@Address", SqlDbType.NVarChar, 50));
            command.Parameters["@Address"].Value = employee.Address;

            command.Parameters.Add(new SqlParameter("@PostalCode", SqlDbType.NVarChar, 8));
            command.Parameters["@PostalCode"].Value = employee.PostalCode;

            command.Parameters.Add(new SqlParameter("@BirthDate", SqlDbType.Date));
            command.Parameters["@BirthDate"].Value = employee.BirthDate;

            command.Parameters.Add(new SqlParameter("@DateOfAdmission", SqlDbType.Date));
            command.Parameters["@DateOfAdmission"].Value = employee.AddDate;

            command.Parameters.Add(new SqlParameter("@Notes", SqlDbType.NText));
            command.Parameters["@Notes"].Value = employee.Notes;

            connection.Open();
            command.ExecuteNonQuery();
            connection.Close();
        }

        public static void deleteEmployee(int employee)
        {
            SqlConnection connection = new SqlConnection("Data Source = ASUS; Initial Catalog = CarRental; Integrated Security = True");
            SqlCommand command = new SqlCommand("deleteEmployee", connection);
            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@EmployeeID", SqlDbType.Int, 0, "EmployeeID"));
            command.Parameters["@EmployeeID"].Value = employee;

            connection.Open();
            command.ExecuteNonQuery();
            connection.Close();


        }
    }

}
