﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using DAL;

namespace DAL
{
    public class DatabaseConnection
    {
        public DatabaseConnection()
        {
            SqlConnection Connection = new SqlConnection("Data Source = ASUS; Initial Catalog = CarRental; Integrated Security = True");
        }
        public SqlConnection Connection { get; }
    }

    public class Location
    {
        private int _locationID;
        private string _location;

        public int LocationID
        {
            get
            {
                return _locationID;
            }
            set
            {
                _locationID = value;
            }
        }

        public string Location_
        {
            get
            {
                return _location;
            }
            set
            {
                _location = value;
            }
        }

        public Location()
        {

        }

        public Location(int locationID)
        {

        }
    }
    public static class Locations
    {
        public static DataTable ListAllLocations()
        {
            SqlConnection connection = new SqlConnection("Data Source = ASUS; Initial Catalog = CarRental; Integrated Security = True");
            string sql = "select LocationID, Location from Location";
            SqlCommand command = new SqlCommand(sql, connection);
            connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(reader);

            return dataTable;
        }

        public static Location ListLocations_byID(int locationID)
        {
            SqlConnection connection = new SqlConnection("Data Source = ASUS; Initial Catalog = CarRental; Integrated Security = True");
            string sql = "select LocationID, Location from Location where LocationID = @LocationID ";
            SqlCommand command = new SqlCommand(sql, connection);

            command.Parameters.Add(new SqlParameter("@LocationID", SqlDbType.Int, 0, "LocationID"));
            command.Parameters["@LocationID"].Value = locationID;

            connection.Open();
            SqlDataReader reader = command.ExecuteReader();

            if (!reader.HasRows)
                return null;

            reader.Read();

            return new Location
            {
                Location_ = reader["Location"].ToString()
            };
        }
    }
}
