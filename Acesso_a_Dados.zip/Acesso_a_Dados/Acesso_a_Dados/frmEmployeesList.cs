﻿using DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Acesso_a_Dados
{
    public partial class frmEmployeesList : Form
    {
        public frmEmployeesList()
        {
            InitializeComponent();
        }

        private void btn_ver_Click(object sender, EventArgs e)
        {
            this.Size = new Size(460, 558);
            
        }

        private void frmEmployeesList_Load(object sender, EventArgs e)
        {
            this.Size = new Size(460, 205);
            lst_funcionarios.DataSource = Employees.ListAll_Employees();
            lst_funcionarios.DisplayMember = "Name";
            lst_funcionarios.ValueMember = "EmployeeID";
        }

        private void lst_funcionarios_SelectedIndexChanged(object sender, EventArgs e)
        {
            int employeeID = Convert.ToInt32(((DataRowView)lst_funcionarios.SelectedItem)["EmployeeID"]);

            Employee emp = Employees.ListAll_EmployeesByID(employeeID);

            lbl_priNome.Text = emp.FirstName;
            lbl_ultNome.Text = emp.LastName;
            lbl_endereco.Text = emp.Address;
            lbl_codPostal.Text = emp.PostalCode;
            lbl_dataNasc.Text = emp.BirthDate;
            lbl_dataAdd.Text = emp.AddDate.ToString();
            lbl_notas.Text = emp.Notes;
        }

        private void lbl_dataAdd_Click(object sender, EventArgs e)
        {

        }

        private void lbl_dataNasc_Click(object sender, EventArgs e)
        {

        }

        private void lbl_codPostal_Click(object sender, EventArgs e)
        {

        }

        private void lbl_endereco_Click(object sender, EventArgs e)
        {

        }

        private void lbl_ultNome_Click(object sender, EventArgs e)
        {

        }

        private void lbl_priNome_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
