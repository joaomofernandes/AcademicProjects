﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using DAL;
using System.Security.Cryptography;

namespace Acesso_a_Dados
{
    public partial class frmPrincipal : Form
    {
        frmAdicionarFuncionario addEmployee = new frmAdicionarFuncionario();
        
        public frmPrincipal()
        {
            InitializeComponent();

        }

        private void adicionarNovoFuncionárioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool jaExiste = false;
            foreach(Form f in this.MdiChildren)
            {
                if(f.GetType()== typeof(frmAdicionarFuncionario))
                {
                    jaExiste = true;
                }
            }

            if (jaExiste == false)
            {
                frmAdicionarFuncionario addEmployee = new frmAdicionarFuncionario();
                addEmployee.MdiParent = this;
                addEmployee.Show();

            }

            

        }

        private void apagarDadosDeFuncionárioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool jaExiste = false;
            foreach(Form f in this.MdiChildren)
            {
                if (f.GetType() == typeof(frmDeleteEmployee))
                { 
                    jaExiste = true; 
                }
               

            }
            if(jaExiste == false)
            {
                frmDeleteEmployee apagarFuncionario = new frmDeleteEmployee();
                apagarFuncionario.MdiParent = this;
                apagarFuncionario.Show();
            }
        }

        private void atualizarDadosDeFuncionárioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool jaExiste = false;
            foreach (Form f in this.MdiChildren)
            {
                if (f.GetType() == typeof(frmAtualizarFuncionario))
                {
                    jaExiste = true;
                }


            }
            if (jaExiste == false)
            {
                frmAtualizarFuncionario atualizarFuncionario = new frmAtualizarFuncionario();
                atualizarFuncionario.MdiParent = this;
                atualizarFuncionario.Show();
            }
        }

        private void verToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool jaExiste = false;
            foreach(Form f in this.MdiChildren)
            {
                if (f.GetType() == typeof(frmEmployeesList))
                {
                    jaExiste = true;
                }

            }
            if (jaExiste == false)
            {
                frmEmployeesList employeesList = new frmEmployeesList();
                employeesList.MdiParent = this;
                employeesList.Show();
            }
        }
    }

}
