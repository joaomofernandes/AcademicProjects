﻿namespace Acesso_a_Dados
{
    partial class frmEmployeesList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lst_funcionarios = new System.Windows.Forms.ListBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btn_ver = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lbl_notas = new System.Windows.Forms.Label();
            this.lbl_priNome = new System.Windows.Forms.Label();
            this.lbl_ultNome = new System.Windows.Forms.Label();
            this.lbl_endereco = new System.Windows.Forms.Label();
            this.lbl_codPostal = new System.Windows.Forms.Label();
            this.lbl_dataNasc = new System.Windows.Forms.Label();
            this.lbl_dataAdd = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lst_funcionarios
            // 
            this.lst_funcionarios.FormattingEnabled = true;
            this.lst_funcionarios.Location = new System.Drawing.Point(12, 12);
            this.lst_funcionarios.Name = "lst_funcionarios";
            this.lst_funcionarios.Size = new System.Drawing.Size(269, 82);
            this.lst_funcionarios.TabIndex = 0;
            this.lst_funcionarios.SelectedIndexChanged += new System.EventHandler(this.lst_funcionarios_SelectedIndexChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(323, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(92, 82);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // btn_ver
            // 
            this.btn_ver.Location = new System.Drawing.Point(163, 110);
            this.btn_ver.Name = "btn_ver";
            this.btn_ver.Size = new System.Drawing.Size(118, 44);
            this.btn_ver.TabIndex = 2;
            this.btn_ver.Text = "Consultar Dados";
            this.btn_ver.UseVisualStyleBackColor = true;
            this.btn_ver.Click += new System.EventHandler(this.btn_ver_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(54, 188);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Primeiro Nome:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(66, 221);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 20);
            this.label2.TabIndex = 4;
            this.label2.Text = "Último Nome:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(88, 250);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "Endereço:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(59, 279);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Código Postal:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 308);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(158, 20);
            this.label5.TabIndex = 7;
            this.label5.Text = "Data de Nascimento:";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(26, 340);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(144, 20);
            this.label6.TabIndex = 8;
            this.label6.Text = "Data de Admissão:";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(34, 372);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(136, 20);
            this.label7.TabIndex = 9;
            this.label7.Text = "Dados Adicionais:";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // lbl_notas
            // 
            this.lbl_notas.Location = new System.Drawing.Point(176, 377);
            this.lbl_notas.Name = "lbl_notas";
            this.lbl_notas.Size = new System.Drawing.Size(247, 119);
            this.lbl_notas.TabIndex = 10;
            this.lbl_notas.Text = "label8";
            // 
            // lbl_priNome
            // 
            this.lbl_priNome.AutoSize = true;
            this.lbl_priNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_priNome.Location = new System.Drawing.Point(213, 188);
            this.lbl_priNome.Name = "lbl_priNome";
            this.lbl_priNome.Size = new System.Drawing.Size(0, 20);
            this.lbl_priNome.TabIndex = 11;
            this.lbl_priNome.Click += new System.EventHandler(this.lbl_priNome_Click);
            // 
            // lbl_ultNome
            // 
            this.lbl_ultNome.AutoSize = true;
            this.lbl_ultNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ultNome.Location = new System.Drawing.Point(213, 221);
            this.lbl_ultNome.Name = "lbl_ultNome";
            this.lbl_ultNome.Size = new System.Drawing.Size(0, 20);
            this.lbl_ultNome.TabIndex = 12;
            this.lbl_ultNome.Click += new System.EventHandler(this.lbl_ultNome_Click);
            // 
            // lbl_endereco
            // 
            this.lbl_endereco.AutoSize = true;
            this.lbl_endereco.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_endereco.Location = new System.Drawing.Point(213, 250);
            this.lbl_endereco.Name = "lbl_endereco";
            this.lbl_endereco.Size = new System.Drawing.Size(0, 20);
            this.lbl_endereco.TabIndex = 13;
            this.lbl_endereco.Click += new System.EventHandler(this.lbl_endereco_Click);
            // 
            // lbl_codPostal
            // 
            this.lbl_codPostal.AutoSize = true;
            this.lbl_codPostal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_codPostal.Location = new System.Drawing.Point(213, 279);
            this.lbl_codPostal.Name = "lbl_codPostal";
            this.lbl_codPostal.Size = new System.Drawing.Size(0, 20);
            this.lbl_codPostal.TabIndex = 14;
            this.lbl_codPostal.Click += new System.EventHandler(this.lbl_codPostal_Click);
            // 
            // lbl_dataNasc
            // 
            this.lbl_dataNasc.AutoSize = true;
            this.lbl_dataNasc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_dataNasc.Location = new System.Drawing.Point(213, 308);
            this.lbl_dataNasc.Name = "lbl_dataNasc";
            this.lbl_dataNasc.Size = new System.Drawing.Size(0, 20);
            this.lbl_dataNasc.TabIndex = 15;
            this.lbl_dataNasc.Click += new System.EventHandler(this.lbl_dataNasc_Click);
            // 
            // lbl_dataAdd
            // 
            this.lbl_dataAdd.AutoSize = true;
            this.lbl_dataAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_dataAdd.Location = new System.Drawing.Point(213, 340);
            this.lbl_dataAdd.Name = "lbl_dataAdd";
            this.lbl_dataAdd.Size = new System.Drawing.Size(0, 20);
            this.lbl_dataAdd.TabIndex = 16;
            this.lbl_dataAdd.Click += new System.EventHandler(this.lbl_dataAdd_Click);
            // 
            // frmEmployeesList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(444, 519);
            this.Controls.Add(this.lbl_dataAdd);
            this.Controls.Add(this.lbl_dataNasc);
            this.Controls.Add(this.lbl_codPostal);
            this.Controls.Add(this.lbl_endereco);
            this.Controls.Add(this.lbl_ultNome);
            this.Controls.Add(this.lbl_priNome);
            this.Controls.Add(this.lbl_notas);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_ver);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lst_funcionarios);
            this.Name = "frmEmployeesList";
            this.Text = "Dados de Funcionários";
            this.Load += new System.EventHandler(this.frmEmployeesList_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lst_funcionarios;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btn_ver;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbl_notas;
        private System.Windows.Forms.Label lbl_priNome;
        private System.Windows.Forms.Label lbl_ultNome;
        private System.Windows.Forms.Label lbl_endereco;
        private System.Windows.Forms.Label lbl_codPostal;
        private System.Windows.Forms.Label lbl_dataNasc;
        private System.Windows.Forms.Label lbl_dataAdd;
    }
}