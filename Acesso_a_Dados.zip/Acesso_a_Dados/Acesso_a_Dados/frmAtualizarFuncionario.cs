﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;
using System.Data.SqlClient;
using System.Drawing.Text;

namespace Acesso_a_Dados
{
    public partial class frmAtualizarFuncionario : Form
    {
        public frmAtualizarFuncionario()
        {
            InitializeComponent();
        }

        public int employeeID { get; set; }
        public int _employeeID { get; set; }

        public void frmAtualizarFuncionario_Load(object sender, EventArgs e)
        {
            Start();

        }

        private void cmb_funcionarios_SelectedIndexChanged(object sender, EventArgs e)
        {
            
           
        }

        private void updateEmployee()
        {
            int location = Convert.ToInt32(((DataRowView)cmb_location.SelectedItem)["LocationID"]);
            string _birthDate = txt_year.Text + "-" + cmb_month.SelectedIndex + "-" + cmb_day.Text;
            string _addDate = txt_addYear.Text + "-" + cmb_addMonth.SelectedIndex + "-" + cmb_addDay.Text;
            employeeID = Convert.ToInt32(((DataRowView)cmb_funcionarios.SelectedItem)["EmployeeID"]);
            


            Employee employee = new Employee
            {
                EmployeeID = employeeID, 
                FirstName = txt_firstName.Text,
                LastName = txt_lastName.Text,
                LocationID = location,
                Address = txt_address.Text,
                PostalCode = txt_postalCode.Text,
                BirthDate = _birthDate,
                AddDate = DateTime.Parse(_addDate),
                Notes = txt_notes.Text
            };

            Employees.updateEmployee(employee);
        }

        private void btn_guardarFunc_Click(object sender, EventArgs e)
        {
            preenchido();
            bool preechido = preenchido();
            if (preechido == false)
            {
                MessageBox.Show("Por favor preencha os campos em falta.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    updateEmployee();
                    MessageBox.Show("Dados de Funcionário alterados com sucesso com sucesso", "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    Start();
                    
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao Alterar Dados Funcionário", "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            updateEmployee();
        }

        private void cmb_funcionarios_SelectionChangeCommitted(object sender, EventArgs e)
        {
            this.Size = new Size(445, 770);
            _employeeID = Convert.ToInt32(((DataRowView)cmb_funcionarios.SelectedItem)["EmployeeID"]);
            Employee employee = Employees.ListAll_EmployeesByID(_employeeID);
            txt_firstName.Text = employee.FirstName;
            txt_lastName.Text = employee.LastName;
            cmb_location.SelectedIndex= employee.LocationID;

            string data = employee.BirthDate;
            string[] _datas = data.Split('/');
            string ano = _datas[_datas.Length - 1];
            string dia = _datas[0];
            int mes = Convert.ToInt32(_datas[1]);
            string[] _ano = ano.Split(' ');
            
            
            string dataAdmissao = employee.AddDate.ToString();
            string[] addDate = dataAdmissao.Split('/');
            string addYear = addDate[addDate.Length - 1];
            string addDay = addDate[0];
            int _addMonth = Convert.ToInt32(addDate[1]);
            string[] Add_Year = addYear.Split(' ');

            cmb_addDay.Text = addDay;
            cmb_addMonth.SelectedIndex = _addMonth;
            txt_addYear.Text = Add_Year[0];

            cmb_day.Text = dia;
            txt_year.Text = _ano[0];
            cmb_month.SelectedIndex = mes;
            txt_address.Text = employee.Address;
            txt_postalCode.Text = employee.PostalCode;
            txt_notes.Text = employee.Notes;
        }

        public bool preenchido()
        {           
                bool var;
                if (
                txt_firstName.Text == "" ||
                txt_lastName.Text == "" ||
                cmb_location.Text == "Selecione um distrito" ||
                txt_address.Text == "" ||
                txt_postalCode.Text == "" ||
                cmb_day.Text == "" ||
                cmb_month.SelectedIndex == 0 ||
                txt_year.Text == "" ||
                txt_notes.Text == "")
                {
                    var = false;
                }
                else
                {
                    var = true;
                }
                return var;

        }
        private void Start()
        {
            this.Size = new Size(445, 195);
            cmb_location.DataSource = Locations.ListAllLocations();
            cmb_location.DisplayMember = "Location";
            cmb_location.ValueMember = "LocationID";
            cmb_funcionarios.Text = "Selecione...";
            picbox_logo.Image = Image.FromFile(@"C:\Users\Utilizador\source\repos\Acesso_a_Dados\Acesso_a_Dados\Resources\img_464825.png");
            picbox_logo.SizeMode = PictureBoxSizeMode.StretchImage;
            cmb_location.Text = "Selecione um distrito";
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            cmb_funcionarios.DataSource = Employees.ListAll_Employees();
            cmb_funcionarios.DisplayMember = "Name";
            cmb_funcionarios.ValueMember = "EmployeeID";
            cmb_funcionarios.Text = "Selecione...";
            txt_firstName.Text = "";
            txt_lastName.Text = "";
            cmb_location.Text = "";
            txt_address.Text = "";
            txt_postalCode.Text = "";
            txt_notes.Text = "";
            cmb_day.Text = "";
            txt_year.Text = "";
            cmb_month.Text = "";
        }
    }
    
}
