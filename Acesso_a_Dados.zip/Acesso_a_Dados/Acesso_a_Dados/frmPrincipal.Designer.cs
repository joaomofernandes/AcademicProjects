﻿namespace Acesso_a_Dados
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.inicioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paginaInicialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.terminarSessãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.funcionáriosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.verToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adicionarNovoFuncionárioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.atualizarDadosDeFuncionárioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.apagarDadosDeFuncionárioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clientesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.novoClienteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.atualizarDadosDeClienteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eliminarDadosDeClienteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inicioToolStripMenuItem,
            this.funcionáriosToolStripMenuItem,
            this.clientesToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1013, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // inicioToolStripMenuItem
            // 
            this.inicioToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.paginaInicialToolStripMenuItem,
            this.terminarSessãoToolStripMenuItem});
            this.inicioToolStripMenuItem.Name = "inicioToolStripMenuItem";
            this.inicioToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.inicioToolStripMenuItem.Text = "Inicio";
            // 
            // paginaInicialToolStripMenuItem
            // 
            this.paginaInicialToolStripMenuItem.Name = "paginaInicialToolStripMenuItem";
            this.paginaInicialToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.paginaInicialToolStripMenuItem.Text = "Novo Aluguer";
            // 
            // terminarSessãoToolStripMenuItem
            // 
            this.terminarSessãoToolStripMenuItem.Name = "terminarSessãoToolStripMenuItem";
            this.terminarSessãoToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.terminarSessãoToolStripMenuItem.Text = "Menu Principal";
            // 
            // funcionáriosToolStripMenuItem
            // 
            this.funcionáriosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.verToolStripMenuItem,
            this.adicionarNovoFuncionárioToolStripMenuItem,
            this.atualizarDadosDeFuncionárioToolStripMenuItem,
            this.apagarDadosDeFuncionárioToolStripMenuItem});
            this.funcionáriosToolStripMenuItem.Name = "funcionáriosToolStripMenuItem";
            this.funcionáriosToolStripMenuItem.Size = new System.Drawing.Size(87, 20);
            this.funcionáriosToolStripMenuItem.Text = "Funcionários";
            // 
            // verToolStripMenuItem
            // 
            this.verToolStripMenuItem.Name = "verToolStripMenuItem";
            this.verToolStripMenuItem.Size = new System.Drawing.Size(269, 22);
            this.verToolStripMenuItem.Text = "Ver";
            this.verToolStripMenuItem.Click += new System.EventHandler(this.verToolStripMenuItem_Click);
            // 
            // adicionarNovoFuncionárioToolStripMenuItem
            // 
            this.adicionarNovoFuncionárioToolStripMenuItem.Name = "adicionarNovoFuncionárioToolStripMenuItem";
            this.adicionarNovoFuncionárioToolStripMenuItem.Size = new System.Drawing.Size(269, 22);
            this.adicionarNovoFuncionárioToolStripMenuItem.Text = "Novo Funcionário";
            this.adicionarNovoFuncionárioToolStripMenuItem.Click += new System.EventHandler(this.adicionarNovoFuncionárioToolStripMenuItem_Click);
            // 
            // atualizarDadosDeFuncionárioToolStripMenuItem
            // 
            this.atualizarDadosDeFuncionárioToolStripMenuItem.Name = "atualizarDadosDeFuncionárioToolStripMenuItem";
            this.atualizarDadosDeFuncionárioToolStripMenuItem.Size = new System.Drawing.Size(269, 22);
            this.atualizarDadosDeFuncionárioToolStripMenuItem.Text = "Atualizar Dados de Funcionário";
            this.atualizarDadosDeFuncionárioToolStripMenuItem.Click += new System.EventHandler(this.atualizarDadosDeFuncionárioToolStripMenuItem_Click);
            // 
            // apagarDadosDeFuncionárioToolStripMenuItem
            // 
            this.apagarDadosDeFuncionárioToolStripMenuItem.Name = "apagarDadosDeFuncionárioToolStripMenuItem";
            this.apagarDadosDeFuncionárioToolStripMenuItem.Size = new System.Drawing.Size(269, 22);
            this.apagarDadosDeFuncionárioToolStripMenuItem.Text = "Excluir Funcionário da Base de Dados";
            this.apagarDadosDeFuncionárioToolStripMenuItem.Click += new System.EventHandler(this.apagarDadosDeFuncionárioToolStripMenuItem_Click);
            // 
            // clientesToolStripMenuItem
            // 
            this.clientesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.novoClienteToolStripMenuItem,
            this.atualizarDadosDeClienteToolStripMenuItem,
            this.eliminarDadosDeClienteToolStripMenuItem});
            this.clientesToolStripMenuItem.Name = "clientesToolStripMenuItem";
            this.clientesToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.clientesToolStripMenuItem.Text = "Clientes";
            // 
            // novoClienteToolStripMenuItem
            // 
            this.novoClienteToolStripMenuItem.Name = "novoClienteToolStripMenuItem";
            this.novoClienteToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.novoClienteToolStripMenuItem.Text = "Novo Cliente";
            // 
            // atualizarDadosDeClienteToolStripMenuItem
            // 
            this.atualizarDadosDeClienteToolStripMenuItem.Name = "atualizarDadosDeClienteToolStripMenuItem";
            this.atualizarDadosDeClienteToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.atualizarDadosDeClienteToolStripMenuItem.Text = "Atualizar Dados de Cliente";
            // 
            // eliminarDadosDeClienteToolStripMenuItem
            // 
            this.eliminarDadosDeClienteToolStripMenuItem.Name = "eliminarDadosDeClienteToolStripMenuItem";
            this.eliminarDadosDeClienteToolStripMenuItem.Size = new System.Drawing.Size(212, 22);
            this.eliminarDadosDeClienteToolStripMenuItem.Text = "Eliminar Dados de Cliente";
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1013, 446);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmPrincipal";
            this.Text = "Car Rental";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem inicioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paginaInicialToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem terminarSessãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem funcionáriosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem verToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adicionarNovoFuncionárioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem atualizarDadosDeFuncionárioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem apagarDadosDeFuncionárioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clientesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem novoClienteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem atualizarDadosDeClienteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eliminarDadosDeClienteToolStripMenuItem;
    }
}

