﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using DAL;

namespace Acesso_a_Dados
{
    public partial class frmAdicionarFuncionario : Form
    {
        
        public frmAdicionarFuncionario()
        {
            InitializeComponent();
            
        }

        private void frmAdicionarFuncionario_Load(object sender, EventArgs e)
        {
            cmb_location.DataSource = Locations.ListAllLocations();
            cmb_location.DisplayMember = "Location";
            cmb_location.ValueMember = "LocationID";
            picbox_logo.Image = Image.FromFile(@"C:\Users\Utilizador\source\repos\Acesso_a_Dados\Acesso_a_Dados\Resources\173-1736986_add-employee-svg-png-icon-free-download-employee.png");
            picbox_logo.SizeMode = PictureBoxSizeMode.StretchImage;
            cmb_location.Text = "Selecione um distrito";
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
           
        }

        public void AddEmployee()
        {

            //SqlConnection connection = new SqlConnection(@"Data Source = ASUS; Initial Catalog = CarRental; Integrated Security = True");
            //SqlCommand command = new SqlCommand("insertNewEmployee", connection);
            //command.CommandType = CommandType.StoredProcedure;

            //command.Parameters.Add(new SqlParameter("@FirstName", SqlDbType.NVarChar, 10));
            //command.Parameters["@FirstName"].Value = txt_firstName.Text;

            //command.Parameters.Add(new SqlParameter("@LastName", SqlDbType.NVarChar, 10));
            //command.Parameters["@LastName"].Value = txt_lastName.Text;

            //command.Parameters.Add(new SqlParameter("@LocationID", SqlDbType.Int));
            //int locationID = Convert.ToInt32(((DataRowView)cmb_location.SelectedItem)["LocationID"]);
            //command.Parameters["@LocationID"].Value = locationID;

            //command.Parameters.Add(new SqlParameter("@Address", SqlDbType.NVarChar, 50));
            //command.Parameters["@Address"].Value = txt_address.Text;

            //command.Parameters.Add(new SqlParameter("@PostalCode", SqlDbType.NVarChar, 8));
            //command.Parameters["@PostalCode"].Value = txt_postalCode.Text;

            //command.Parameters.Add(new SqlParameter("@BirthDate", SqlDbType.Date));
            //string date = txt_year.Text + "-" + cmb_month.SelectedIndex + "-" + cmb_day.Text;
            //command.Parameters["@BirthDate"].Value = date;

            //command.Parameters.Add(new SqlParameter("@DateOfAdmission", SqlDbType.Date));
            //DateTime dateTime = DateTime.Now;
            //command.Parameters["@DateOfAdmission"].Value = dateTime;

            //command.Parameters.Add(new SqlParameter("@Notes", SqlDbType.NText));
            //command.Parameters["@Notes"].Value = txt_notes.Text;


            //    connection.Open();
            //    command.ExecuteNonQuery();
            //    MessageBox.Show("Funcionário adicionado com sucesso", "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Information);

            //connection.Close();
            
            
                int location = Convert.ToInt32(((DataRowView)cmb_location.SelectedItem)["LocationID"]);
                string _birthDate = txt_year.Text + "-" + cmb_month.SelectedIndex + "-" + cmb_day.Text;
            
                DateTime addDate = DateTime.Now;
                Employee employee = new Employee
                {
                    FirstName = txt_firstName.Text,
                    LastName = txt_lastName.Text,
                    LocationID = location,
                    Address = txt_address.Text,
                    PostalCode = txt_postalCode.Text,
                    BirthDate = _birthDate,
                    AddDate = addDate,
                    Notes = txt_notes.Text
                };

                Employees.AddEmployee(employee);
            
           
            

        }

        private void btn_guardarFunc_Click(object sender, EventArgs e)
        {
            try
            {
                preenchido();
                bool preechido = preenchido();
                if (preechido == false)
                {
                    MessageBox.Show("Por favor preencha os campos em falta.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    try
                    {
                        AddEmployee();
                        MessageBox.Show("Funcionário adicionado com sucesso", "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Erro ao adicionar funcionário", "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                }
            }
            catch(Exception ex)
            {
                string exception = ex.Message;
                MessageBox.Show(exception, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
           


            

        }

        private void frmAdicionarFuncionario_FormClosing(object sender, FormClosingEventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txt_firstName.Text = "";
            txt_lastName.Text = "";
            cmb_location.Text = "Selecione um distrito";
            txt_address.Text = "";
            txt_postalCode.Text = "";
            cmb_day.Text = "";
            cmb_month.SelectedIndex = 0;
            txt_year.Text = "";
            txt_notes.Text = "";
        }

        private bool preenchido()
        {
            bool var;
            if (
            txt_firstName.Text == "" ||
            txt_lastName.Text == "" ||
            cmb_location.Text == "Selecione um distrito" ||
            txt_address.Text == "" ||
            txt_postalCode.Text == "" ||
            cmb_day.Text == "" ||
            cmb_month.SelectedIndex == 0 ||
            txt_year.Text == "" ||
            txt_notes.Text == "")
            {
                var = false;
            }
            else
            {
                var = true;
            }
                return var;

            
        }
    }
}
