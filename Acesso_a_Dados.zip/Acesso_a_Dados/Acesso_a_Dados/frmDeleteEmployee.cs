﻿using DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Acesso_a_Dados
{
    public partial class frmDeleteEmployee : Form
    {
        
        public frmDeleteEmployee()
        {
            InitializeComponent();
            cmb_showEmployees.Text = "Selecione...";
        }

        private void frmDeleteEmployee_Load(object sender, EventArgs e)
        {
            this.Size = new Size(416, 134);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            label2.Hide();
            cmb_showEmployees.DataSource = Employees.ListAll_Employees();
            cmb_showEmployees.DisplayMember = "Name";
            cmb_showEmployees.ValueMember = "EmployeeID";
            cmb_showEmployees.Text = "Selecione...";
            pictureBox1.Image = Properties.Resources._277_512;
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;

        }

        private void btn_excluir_Click(object sender, EventArgs e)
        {
            string nome = cmb_showEmployees.Text;
            DialogResult dialog = MessageBox.Show("Tem a certeza que pretende excluir" + " " + nome + " " + "da Base de Dados?",
                "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            if (dialog == DialogResult.Yes)
            {
                try
                {
                    deleteEmployee();
                    MessageBox.Show("Funcionário Excluído da Base de Dados com Sucesso.", "Mensagem", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Erro ao Excluir Funcionário da Base de Dados.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void deleteEmployee()
        {
            int employee = Convert.ToInt32(((DataRowView)cmb_showEmployees.SelectedItem)["EmployeeID"]);
            Employees.deleteEmployee(employee);

        }

        private void cmb_showEmployees_SelectionChangeCommitted(object sender, EventArgs e)
        {
            this.Size = new Size(416, 218);
            label2.Show();
        }
    }
}
