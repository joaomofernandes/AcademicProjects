﻿using System;

namespace Meu_programa
{
    class Program
    {
        public static void Main(string[] args)
        {
            bool MostrarMenu = true;
            while (MostrarMenu)
            {
                MostrarMenu = Menu();
            }
        }  
        public static bool Menu()
        {
            Console.Clear();
            Console.WriteLine("Bem-vindo! Por favor indique o seu nome");
            string nome = Console.ReadLine();
            Console.Clear();
            Console.WriteLine("####################### MEU PROGRAMA ############################");
            int Horaatual = DateTime.Now.Hour;
            if (Horaatual <= 12)
            {
                Console.WriteLine("Bom dia, " + nome);
            }
            else if (Horaatual >=12 & Horaatual <20)
            {
                Console.WriteLine("Boa tarde, " + nome, "!!!");
            }
            else if (Horaatual >=20 & Horaatual <24)
            {
                Console.WriteLine("Boa noite, " + nome);
            }
            DateTime hoje = DateTime.Now;
            Console.WriteLine("Hoje é " + hoje);
            Console.WriteLine("");
            Console.WriteLine("1) Conversão de Temperatura");
            Console.WriteLine("2) Conversão de Câmbio");
            Console.WriteLine("3) Peso ideal");
            Console.WriteLine("4) Cálculo de Combustivél/Autonomia");
            Console.WriteLine("5) Figuras");
            Console.WriteLine("6) Calculadora");
            Console.WriteLine("7) Sair do Programa");
            Console.Write("Escolha uma das opçôes: ");

            switch (Console.ReadLine())
            {
                case "1":
                    MenuConversao();
                    return true;
                case "2":
                    MenuConversaoCambio();
                    return true;
                case "3":
                    Console.WriteLine("Por favor indique a sua altura em Metros");
            double altura = double.Parse(Console.ReadLine());
            Console.WriteLine("Por favor indique o seu género");
            string genero = Console.ReadLine();
            string masc = "M";
            string fem = "F";

            if (genero == masc)
            {
                double pesoidealM = (72.5 * altura) - 58;
                Console.WriteLine("O seu peso ideal é " + pesoidealM.ToString());
            }
            else if (genero == fem)
            {
                double pesoidealF = (62.1 * altura) - 44.7;
                Console.WriteLine("O seu peso ideal é " + pesoidealF.ToString());
                
            }

            else
            {
                Console.WriteLine("O caractere que indicou não é valido");
            }
                    return true;
                case "4":
                    Combustivél();
                    return true;
                case "5":
                    Figuras();
                    return true;
                case "6":
                    calculadora();
                    return true;
                case "7":
                    Console.Clear();
                    Console.WriteLine("Obrigado por usar esta aplicação :)");
                    return false;
                default:
                    return true;
            }

        }
        static bool MenuConversao()
        {
                Console.Clear();
                Console.WriteLine("############ CONVERSÃO DE TEMPERATURAS #############");
                Console.WriteLine();
                Console.WriteLine("Qual das conversões deseja efetuar? Indique com a letra correspondente");
                Console.WriteLine();
                Console.WriteLine(" (F) Converter Celsius para Fahrenheit ");
                Console.WriteLine(" (C) Converter Fahrenheit para Celsius");
               
                switch (Console.ReadLine())
                {
                    case "F":
                    Console.Clear();
                    Console.WriteLine("Indique a temperatura em Celsius que deseja converter");
                    double Fahr = double.Parse(Console.ReadLine());
                    double conversF = (9 / 5) * Fahr + 32;
                    Console.WriteLine("O valor convertido em Fahrenheit é: " + conversF);
                    Console.WriteLine("");
                    Console.WriteLine("Deseja efeuar mais alguma tarefa? (S/N)");
                    switch (Console.ReadLine())
                    {
                        case "S":
                            return true;
                        case "N":
                            return false;
                    }
                    Console.ReadLine();
                    return true;

                    case "C":
                    Console.Clear();
                    Console.WriteLine("Indique a temperatura em Fahrenheit que deseja converter");
                    double Cels = double.Parse(Console.ReadLine());
                    double conversC = (Cels - 32) * 5 / 9;
                    Console.WriteLine("O valor convertido em Celsius é: " + conversC);
                    Console.WriteLine("Deseja efeuar mais alguma tarefa? (S/N)");
                    switch (Console.ReadLine())
                    {
                        case "S":
                            return true;
                        case "N":
                            return false;
                    }
                    Console.ReadLine();
                    return true;
                    
                    default:
                    return true;
                }
                                
        }       
        public static bool MenuConversaoCambio()
        {
            Console.Clear();
            Console.WriteLine("############ CONVERSÃO DE CÂMBIO #############");
            Console.WriteLine();
            Console.WriteLine("Qual das moedas deseja converter? Indique com o número correspondente");
            Console.WriteLine(); 
            Console.WriteLine(" 1) Euros");
            Console.WriteLine(" 2) Libra Esterlina");
            Console.WriteLine(" 3) Dolar");

            switch (Console.ReadLine())
            {
                case "1":
                    Console.Clear();
                    Console.WriteLine("Para que Câmbio deseja converter?");
                    Console.WriteLine(" 1) Libra");
                    Console.WriteLine(" 2) Dólar");
                    switch (Console.ReadLine())
                    {
                        case "1":
                            Console.Clear();
                            Console.WriteLine("Indique o valor em Euros");
                            double Valor = double.Parse(Console.ReadLine());
                            double ConversLibra = Valor * 0.84;
                            Console.WriteLine("O valor que inseriu em euros, equivale em Libras a " + ConversLibra);
                            Console.WriteLine("Deseja efeuar mais alguma tarefa? (S/N)");
                            switch (Console.ReadLine())
                            {
                                case "S":
                                    return true;
                                case "N":
                                    return false;
                            }
                            Console.ReadLine();
                            return true;

                        case "2":
                            Console.Clear();
                            Console.WriteLine("Indique o valor em Euros");
                            double ValorE = double.Parse(Console.ReadLine());
                            double ConversDolar = ValorE * 1.09;
                            Console.WriteLine("O valor que inseriu em euros, equivale em Dólares a " + ConversDolar);
                            Console.WriteLine("Deseja efeuar mais alguma tarefa? (S/N)");
                            switch (Console.ReadLine())
                            {
                                case "S":
                                    return true;
                                case "N":
                                    return false;
                            }
                            Console.ReadLine();
                            return true;
                        default:
                            return true;
                    }
                
                case "2":
                    Console.Clear();
                    Console.WriteLine("Para que câmbio deseja converter?");
                    Console.WriteLine(" 1) Euro");
                    Console.WriteLine(" 2) Dólar");
                    switch (Console.ReadLine())
                    {
                        case "1":
                            Console.Clear();
                            Console.WriteLine("Indique o valor em Libras");
                            double Valor = double.Parse(Console.ReadLine());
                            double ConversEuro = Valor * 1.20;
                            Console.WriteLine("O valor que inseriu em Libras, equivale em Euros a " + ConversEuro);
                            Console.WriteLine("Deseja efeuar mais alguma tarefa? (S/N)");
                            switch (Console.ReadLine())
                            {
                                case "S":
                                    return true;
                                case "N":
                                    return false;
                            }
                            Console.ReadLine();
                            return true;

                        case "2":
                            Console.Clear();
                            Console.WriteLine("Indique o valor em Libras");
                            double ValorD = double.Parse(Console.ReadLine());
                            double ConversDolar = ValorD * 1.30;
                            Console.WriteLine("O valor que inseriu em euros, equivale em Dólares a " + ConversDolar);
                            Console.WriteLine("Deseja efeuar mais alguma tarefa? (S/N)");
                            switch (Console.ReadLine())
                            {
                                case "S":
                                    return true;
                                case "N":
                                    return false;
                            }
                            Console.ReadLine();
                            return true;
                        default:
                            return true;
                    }
                    

                case "3":
                    Console.Clear();
                    Console.WriteLine("Para que câmbio deseja converter?");
                    Console.WriteLine(" 1) Euro");
                    Console.WriteLine(" 2) Libra");
                    switch (Console.ReadLine())
                    {
                        case "1":
                            Console.Clear();
                            Console.WriteLine("Indique o valor em Dólares");
                            double Valor = double.Parse(Console.ReadLine());
                            double ConversEuros = Valor * 0.92;
                            Console.WriteLine("O valor que inseriu em euros, equivale em Libras a " + ConversEuros);
                            Console.WriteLine("Deseja efeuar mais alguma tarefa? (S/N)");
                            switch (Console.ReadLine())
                            {
                                case "S":
                                    return true;
                                case "N":
                                    return false;
                            }
                            Console.ReadLine();
                            return true;

                        case "2":
                            Console.Clear();
                            Console.WriteLine("Indique o valor em Dólares");
                            double ValorL = double.Parse(Console.ReadLine());
                            double ConversDolar = ValorL * 0.77;
                            Console.WriteLine("O valor que inseriu em euros, equivale em Dólares a " + ConversDolar);
                            Console.WriteLine("Deseja efeuar mais alguma tarefa? (S/N)");
                            switch (Console.ReadLine())
                            {
                                case "S":
                                    return true;
                                case "N":
                                    return false;
                            }
                            Console.ReadLine();
                            return true;
                        default:
                            return true;

                    }
                    
                default:
                    return true;
            }
        }
        static void Combustivél()
        {
            Console.Clear();
            Console.WriteLine("############## CONSUMO COMBUSTÍVEL ##############");
            Console.WriteLine("1) Consumo Médio");
            Console.WriteLine("2) Autonomia");
            Console.WriteLine("Indique qual o cálculo que deseja efetuar");
            string calculo = Console.ReadLine();
            string consumo = "1";
            string autonomia = "2";
            if (calculo == consumo)
            {
                Console.WriteLine("Indique quantos litros de combustivel colocou no depósito");
                double litros = double.Parse(Console.ReadLine());
                Console.WriteLine("Agora indique quantos quilometros percorreu desde então");
                int distancia = int.Parse(Console.ReadLine());
                double consumomedio = litros / distancia * 100;
                Console.WriteLine("O consumo médio de combustivel foi de " + consumomedio, "litros a cada 100 Kms");
                decisao();

            }

            else if (calculo == autonomia)
            {
                Console.Clear();
                Console.WriteLine("Indique o consumo médio do seu automóvel");
                double media = double.Parse(Console.ReadLine());
                Console.WriteLine("Agora indique a capacidade do tanque em Litros");
                int deposito = int.Parse(Console.ReadLine());
                double autonomia_media = (deposito / media) * 100;
                Console.WriteLine("A autonomia esperada é " + autonomia_media);
                decisao();
                Console.ReadLine();
            }
            
        }
        
        static bool decisao()
        {
            Console.WriteLine("Deseja efetuar mais alguma tarefa? (S/N)");
            switch (Console.ReadLine())
            {
                case "S":
                    return true;
                case "N":
                    return false;
                default:
                    return true;
            }

        }
         
       

        static bool calculadora()
        {
            Console.Clear();
            Console.WriteLine("####################### CALCULADORA ############################");
            Console.WriteLine("");
            Console.WriteLine("Qual das operações deseja efetuar? Indique com o respetivo número");
            Console.WriteLine("");
            Console.WriteLine("1) Soma");
            Console.WriteLine("2) Subtração");
            Console.WriteLine("3) Multiplicação");
            Console.WriteLine("4) Divisão");
            Console.WriteLine("5) Cálculo de média");
            Console.WriteLine("6) Potência de um número");
            Console.WriteLine("7) Raíz Quadrada");
            switch (Console.ReadLine())
            {
                case "1":
                    Console.Clear();
                    Console.WriteLine("Indique quantos valores pretende somar");
                    int qtd_soma = int.Parse(Console.ReadLine());
                    int cont_soma = 1;
                    double total_soma = 0;
                    while (cont_soma <= qtd_soma)
                    {
                        Console.Clear();
                        Console.WriteLine("");
                        double valor_soma = int.Parse(Console.ReadLine());
                        total_soma = total_soma + valor_soma;
                        cont_soma = cont_soma + 1;
                    }
                    Console.Clear();
                    Console.WriteLine("RESULTADO: " + total_soma);
                    Console.WriteLine("Deseja efetuar mais algum cálculo? (S/N)");
                    switch (Console.ReadLine())
                    {
                        case "S":
                            calculadora();
                            return true;
                        case "N":
                            Menu();
                            return true;
                    }
                    
                    return true;
                case "2":
                    Console.Clear();
                    Console.WriteLine("Indique quantos valores pretende subtrair");
                    int qtd_sub = int.Parse(Console.ReadLine());
                    int cont_sub = 1;
                    double total_sub = 0;
                    while (cont_sub <= qtd_sub)
                    {
                        Console.Clear();
                        Console.WriteLine("");
                        double valor_sub = int.Parse(Console.ReadLine());
                        total_sub = total_sub - valor_sub;
                    }
                    Console.Clear();
                    Console.WriteLine("RESULTADO: " + total_sub);
                    Console.WriteLine("Deseja efetuar mais algum cálculo? (S/N)");
                    switch (Console.ReadLine())
                    {
                        case "S":
                            calculadora();
                            return true;
                        case "N":
                            Menu();
                            return true;
                    }
                    return true;
                case "3":
                    Console.Clear();
                    Console.WriteLine("Indique quantos valores pretende multiplicar");
                    int qtd_mul = int.Parse(Console.ReadLine());
                    int cont_mul = 1;
                    double total_mul = 0;
                    while (cont_mul <= qtd_mul)
                    {
                        Console.Clear();
                        Console.WriteLine("");
                        double valor_mul = int.Parse(Console.ReadLine());
                        total_mul = total_mul * valor_mul;
                    }
                    Console.Clear();
                    Console.WriteLine("RESULTADO: " + total_mul);
                    Console.WriteLine("Deseja efetuar mais algum cálculo? (S/N)");
                    switch (Console.ReadLine())
                    {
                        case "S":
                            calculadora();
                            return true;
                        case "N":
                            Menu();
                            return true;
                    }
                    return true;
                case "4":
                    Console.Clear();
                    Console.WriteLine("Digite o dividendo");
                    double dividendo = double.Parse(Console.ReadLine());
                    Console.Clear();
                    Console.WriteLine("Agora digite o divisor");
                    double divisor = double.Parse(Console.ReadLine());
                    if (divisor > dividendo)
                    {
                        Console.WriteLine("Não é possível efetuar a divisão");
                        return calculadora();
                    }
                    else if (dividendo ==0)
                    {
                        Console.WriteLine("Não é possível efetuar a divisão");
                        return calculadora();
                    }
                    else
                    {
                        double resultado = dividendo / divisor;
                        double resto = dividendo % divisor;
                        Console.WriteLine("Resultado: " + resultado);
                        Console.WriteLine("Resto da divisão " + resto);
                    }
                    Console.WriteLine("Deseja efetuar mais algum cálculo? (S/N)");
                    switch (Console.ReadLine())
                    {
                        case "S":
                            calculadora();
                            return true;
                        case "N":
                            Menu();
                            return true;
                    }
                    return true;
                case "5":
                    Console.Clear();
                    Console.WriteLine("Por favor indique o nome do aluno");
                    string nome = Console.ReadLine();
                    Console.WriteLine("Indique o número de testes que foram feitos por " + nome);
                    int qtd = int.Parse(Console.ReadLine());
                    int cont = 1;
                    double total = 0;
                    while (cont <= qtd)
                    {
                        Console.WriteLine("Por favor indique as notas obtidas pelo aluno");
                        double valor = double.Parse(Console.ReadLine());
                        total = total + valor;
                        cont = cont + 1;
                    }

                    Console.WriteLine("Total " + total);
                    double media = total / qtd;
                    double mediafinal = Math.Round(media);
                    Console.WriteLine("Média: " + media);
                    return true;
                case "6":
                    Console.Clear();
                    Console.WriteLine("Indique um número");
                    int num = int.Parse(Console.ReadLine());
                    Console.Clear();
                    Console.WriteLine("Agora indique a potência");
                    int pot = int.Parse(Console.ReadLine());
                    double potencia = Math.Pow(num, pot);
                    Console.Clear();
                    Console.WriteLine("Resultado: " + potencia);
                    Console.WriteLine("Deseja efetuar mais algum cálculo? (S/N)");
                    switch (Console.ReadLine())
                    {
                        case "S":
                            calculadora();
                            return true;
                        case "N":
                            Menu();
                            return true;
                    }
                    return true;
                    
                case "7":
                    Console.Clear();
                    Console.WriteLine("Indique um número");
                    int N = int.Parse(Console.ReadLine());
                    double rquadrada = Math.Sqrt(N);
                    Console.Clear();
                    Console.WriteLine("Resultado: " + rquadrada);
                    Console.WriteLine("Deseja efetuar mais algum cálculo? (S/N)");
                    switch (Console.ReadLine())
                    {
                        case "S":
                            calculadora();
                            return true;
                        case "N":
                            Menu();
                            return true;
                    }
                    return true;
                default:
                    return true;
            }
        }
        
        static void Figuras()
        {

        }
    }
}
