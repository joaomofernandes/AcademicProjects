﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Toponima.Classes;
using Toponimia.Classes;

namespace Toponimia
{
    public partial class LoginPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_Entrar_Click(object sender, EventArgs e)
        {
            Utilizador user = new Utilizador();
            DAL d = new DAL();

            user.nome = txtU.Value;
            user.pass = txtP.Value;

            bool userValido = d.UtilizadorValido(user);

            if(userValido == true)
            {
                Session["Utilizador_Validado"] = userValido;
                Response.Redirect("inserir.aspx");
            }
            else
            {
                Response.Redirect("loginpage.aspx");
            }



            //Response.Redirect("default.aspx?u=" + txtU.Value);

            //txtU.Value = "";
            //txtP.Value = "";

            ////Executar na página o JavaScript "alert('sucesso!')" após o PostBack
            //ScriptManager.RegisterStartupScript
            //    (this.Page, this.Page.GetType(), "anyKey", "alert('sucesso!')", true);
        }
    }
}