﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using Toponimia.Classes;

namespace Toponimia
{
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {
        [WebMethod]
        public string ObterNomeDistritoById(int idDistrito)
        {
            return new DAL().ObterDistritoById(idDistrito).Designacao;
        }
        [WebMethod]
        public Distrito ObterDistritoById(int idDistrito)
        {
            return new DAL().ObterDistritoById(idDistrito);
        }
    }
}
