﻿using System;
using System.Collections.Generic;
using System.Web.Services;
using Toponimia.Classes;

namespace Toponimia
{
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    [System.Web.Script.Services.ScriptService]
    public class OMeuWebService : System.Web.Services.WebService
    {
        [WebMethod]
        public List<Distrito> ObterDistritos()
        {
            return new DAL().ObterDistritos();
        }
        [WebMethod]
        public List<Concelho> ObterConcelhosByDistrito(int id)
        {
            return new DAL().ObterConcelhosByDistrito(id);
        }
        [WebMethod]
        public List<Freguesia> ObterFreguesiasByConcelho(int id)
        {
            return new DAL().ObterFreguesiasByConcelho(id);
        }
        [WebMethod]
        public List<Arruamento> ObterArruamentosByFreguesia(int id)
        {
            return new DAL().ObterArruamentosByFreguesia(id);
        }







        [WebMethod]
        public void Metodo1()
        {

        }
        [WebMethod]
        public int ObterInteiro()
        {
            WSTestes.WebServiceTesteSoapClient cliente = 
                new WSTestes.WebServiceTesteSoapClient();

            return cliente.ObterInteiro();
        }
        private int _obterInteiro()
        { return 199; }
        [WebMethod]
        public void Metodo2()
        {

        }
        public int MyProperty { get; set; }
        public void MetodoCalculoVencimentosTemporario()
        {

        }
        [WebMethod]
        public MyObject Metodo3()
        {
            return null;
        }
    }

    public class MyObject
    {
        public int MyProperty { get; set; }
        public int MyProperty2 { get; set; }
        public int MyProperty3 { get; set; }
        public int MyProperty4 { get; set; }
        public MyObject2 MyProperty5 { get; set; }
    }
    public class MyObject2
    {

    }

}
