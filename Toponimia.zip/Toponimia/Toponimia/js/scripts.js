﻿var erros;
function Validar() {
    LimparErros();
    erros = [];
    TestarInputPreenchido("txtNome");
    TestarInputPreenchido("txtEmail");
    TestarEmail("txtEmail");

    if (erros != null && erros.length > 0) {
        EscreveErros();
    }
    else {

        $("#txtNome").css("background-color", "#000000");

        //LimparErros();
        alert("Tudo certo!");
    }
}
function TestarInputPreenchido(obj) {
    if ($("#" + obj).val() == "")
        erros.push($("#" + obj + "_Label"));
}
function TestarEmail(obj) {
    var regex = /^[A-Za-z0-9._-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/;
    if (!regex.test($("#" + obj).val())) {
        erros.push($("#" + obj + "_Label"));
        $("#" + obj + "_Label").text("Email errado");
    }
}
function EscreveErros() {
    for (x in erros) {
        erros[x].show();
    }
}
function LimparErros() {
    $("#txtNome_Label").hide();
    $("#txtEmail_Label").hide();
    $("#txtEmail_Label").text("Falta o email");
}

//if ($("#txtNome").val() == "") {
//    $("#txtNome_Label").text("Falta o nome");
//}
//else if ($("#txtEmail").val() == "") {
//    $("#txtEmail_Label").text("Falta o email");
//}
//else if (!EmailValido($("#txtEmail").val())) {
//    $("#txtEmail_Label").text("Email tem formato errado!");
//}
//else
//    alert("Tudo certo!");
//}

function EmailValido(email) {
    var regex = /^[A-Za-z0-9._-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/;
    return regex.test(email);
}