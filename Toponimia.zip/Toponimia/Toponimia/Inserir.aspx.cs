﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Toponimia.Classes;

namespace Toponimia
{
    public partial class Inserir : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Verificar se existe na Session um utilizador validado
            if (Session["Utilizador_Validado"] != null)
            {
                if ((bool)Session["Utilizador_Validado"] == false)
                {
                    //Redirecionar para a página de Login
                    Response.Redirect("loginpage.aspx");
                }
            }
            else 
            {
                //Redirecionar para a página de Login
                Response.Redirect("loginpage.aspx");
            }
            
            
            //***********************************************************
            //Só continua a partir daqui se o utilizador estiver validado

            if (!Page.IsPostBack)
            {
                //Carregamento de dados feito quando a página é pedida a primeira vez
                CarregarDistritos();
                CarregarConcelhos();
                CarregarFreguesias();
                CarregarTpArruamentos();
                CarregarArruamentos();
            }
        }
        protected void CarregarDistritos()
        {
            DAL d = new DAL();
            List<Distrito> listaDist = d.ObterDistritos();

            ddlDistritos.DataTextField = "Designacao";
            ddlDistritos.DataValueField = "Id";

            ddlDistritos.DataSource = listaDist;
            ddlDistritos.DataBind();
        }
        protected void CarregarConcelhos()
        {
            DAL d = new DAL();
            List<Concelho> listaConc = d.ObterConcelhos();

            ddlConcelhos.DataTextField = "Designacao";
            ddlConcelhos.DataValueField = "Id";

            ddlConcelhos.DataSource = listaConc;
            ddlConcelhos.DataBind();
        }
        protected void CarregarFreguesias()
        {
            DAL d = new DAL();
            List<Freguesia> listaFreg = d.ObterFreguesias();

            ddlFreguesias.DataTextField = "Designacao";
            ddlFreguesias.DataValueField = "Id";

            ddlFreguesias.DataSource = listaFreg;
            ddlFreguesias.DataBind();
        }
        protected void CarregarTpArruamentos()
        {
            DAL d = new DAL();
            List<TipoArrumento> listaTpArr = d.ObterTpArruamentos();

            ddlTpArruamentos.DataTextField = "Designacao";
            ddlTpArruamentos.DataValueField = "Id";

            ddlTpArruamentos.DataSource = listaTpArr;
            ddlTpArruamentos.DataBind();
        }
        protected void CarregarArruamentos()
        {
            DAL d = new DAL();
            List<Arruamento> listaArr = d.ObterArruamentos();

            gvArruamentos.DataSource = listaArr;
            gvArruamentos.DataBind();

            ddlArruamentosInicio.DataTextField = "Designacao";
            ddlArruamentosInicio.DataValueField = "Id";
            ddlArruamentosFim.DataTextField = "Designacao";
            ddlArruamentosFim.DataValueField = "Id";

            ddlArruamentosInicio.DataSource = listaArr;
            ddlArruamentosInicio.DataBind();
            //Esta linha serve para acrescentar à dropdownlist um elemento
            //na posição 0 (primeira posição) um elemento
            //com o id=-1 e o texto indicado
            //para que quando queremos inserir um arruamento que ainda não tem
            //disponíveis os arruamento de inicio e/ou fim, seja deixado
            //o valor -1 nesses campos
            ddlArruamentosInicio.Items.Insert(0, new ListItem("--Selecionar Arruamento--","-1"));
            
            ddlArruamentosFim.DataSource = listaArr;
            ddlArruamentosFim.DataBind();
            //Esta linha serve para acrescentar à dropdownlist um elemento
            //na posição 0 (primeira posição) um elemento
            //com o id=-1 e o texto indicado
            //para que quando queremos inserir um arruamento que ainda não tem
            //disponíveis os arruamento de inicio e/ou fim, seja deixado
            //o valor -1 nesses campos
            ddlArruamentosFim.Items.Insert(0, new ListItem("--Selecionar Arruamento--", "-1"));
            
        }

        protected void btnInsertDistritos_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtInsertDistritos.Text))
            {
                Distrito dist = new Distrito();
                dist.Designacao = txtInsertDistritos.Text;
                DAL d = new DAL();
                if (d.InserirDistrito(dist))
                {
                    txtInsertDistritos.Text = "";
                    //Atualizar a dropdownlist dos distritos depois de inserir com sucesso
                    CarregarDistritos();
                }
            }
        }

        protected void btnInsertTpArruamento_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtInsertTpArruamento.Text))
            {
                TipoArrumento tp = new TipoArrumento();
                tp.Designacao = txtInsertTpArruamento.Text;
                DAL d = new DAL();
                if (d.InserirTipoArruamento(tp))
                {
                    txtInsertTpArruamento.Text = "";
                    CarregarTpArruamentos();
                }
            }
        }

        protected void btnInsertConcelho_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtInsertConcelho.Text))
            {
                if (ddlDistritos.Items.Count > 0)
                {
                    Concelho c = new Concelho();
                    c.Designacao = txtInsertConcelho.Text;
                    c.Distrito = new Distrito();
                    c.Distrito.Id = int.Parse(ddlDistritos.SelectedValue);
                    DAL d = new DAL();
                    if (d.InserirConcelho(c))
                    {
                        txtInsertConcelho.Text = "";
                        CarregarConcelhos();
                    }
                }
            }
        }

        protected void btnInsertFreguesia_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtInsertFreguesia.Text))
            {
                if (ddlConcelhos.Items.Count > 0)
                {
                    Freguesia f = new Freguesia();
                    f.Designacao = txtInsertFreguesia.Text;
                    f.Concelho = new Concelho();
                    f.Concelho.Id = int.Parse(ddlConcelhos.SelectedValue);
                    DAL d = new DAL();
                    if (d.InserirFreguesia(f))
                    {
                        txtInsertFreguesia.Text = "";
                        CarregarFreguesias();
                    }
                }
            }
        }

        protected void btnInsertArruamento_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtInsertArruamento.Text)
                    && !string.IsNullOrEmpty(txtInsertArruamentoExtensao.Text)
                    && !string.IsNullOrEmpty(txtInsertArruamentoLongitude.Text)
                    && !string.IsNullOrEmpty(txtInsertArruamentoLatitude.Text))
                {
                    if (ddlTpArruamentos.Items.Count > 0)
                    {
                        if (ddlFreguesias.Items.Count > 0)
                        {
                            Arruamento a = new Arruamento();
                            a.Designacao = txtInsertArruamento.Text;
                            a.TipoArruamento = new TipoArrumento();
                            a.TipoArruamento.Id = int.Parse(ddlTpArruamentos.SelectedValue);
                            a.Freguesia = new Freguesia();
                            a.Freguesia.Id = int.Parse(ddlFreguesias.SelectedValue);
                            a.Inicio = new Arruamento();
                            a.Inicio.Id = int.Parse(ddlArruamentosInicio.SelectedValue);
                            a.Fim = new Arruamento();
                            a.Fim.Id = int.Parse(ddlArruamentosFim.SelectedValue);
                            a.Extensao = int.Parse(txtInsertArruamentoExtensao.Text);
                            a.Longitude = txtInsertArruamentoLongitude.Text;
                            a.Latitude = txtInsertArruamentoLatitude.Text;

                            DAL d = new DAL();
                            if (d.InserirArruamento(a))
                            {
                                txtInsertArruamento.Text = "";
                                txtInsertArruamentoExtensao.Text = "";
                                txtInsertArruamentoLongitude.Text = "";
                                txtInsertArruamentoLatitude.Text = "";

                                //Estas 2 linhas servem para colocar a seleção das 
                                //dropdownlists de tipos de arruamentos e freguesias
                                //na primeira posição
                                ddlTpArruamentos.SelectedIndex = 0;
                                ddlFreguesias.SelectedIndex = 0;

                                CarregarArruamentos();
                            }
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                new DAL().InserirLog(LogType.ERROR,ex.Message);
            }
        }
    }
}