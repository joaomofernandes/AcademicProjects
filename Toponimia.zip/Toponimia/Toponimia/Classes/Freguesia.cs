﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Toponimia.Classes
{
    public class Freguesia
    {
        public int Id { get; set; }
        public string Designacao { get; set; }
        public Concelho Concelho { get; set; }
    }
}