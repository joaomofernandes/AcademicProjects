﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Toponimia.Classes
{
    public class Concelho
    {
        public int Id { get; set; }
        public string Designacao { get; set; }
        public Distrito Distrito { get; set; }
    }
}