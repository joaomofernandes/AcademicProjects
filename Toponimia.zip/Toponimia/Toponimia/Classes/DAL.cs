﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Web;
using Toponima.Classes;

namespace Toponimia.Classes
{
    public static class CamposTabelas
    {
        //Estas variáveis guardam os campos de cada tabela excepto o Id (chave primária)
        public static string TbArruamento = "Designacao,TipoArruamento,Freguesia,Inicio,Fim,Extensao,Longitude,Latitude";
        public static string TbTipoArruamento = "Designacao";
        public static string TbDistrito = "Designacao";
        public static string TbConcelho = "Designacao,Distrito";
        public static string TbFreguesia = "Designacao,Concelho";
        public static string TbLog = "Tipo,Mensagem";
    }

    public class DAL
    {
        //Variável de conexão à base de dados
        private OleDbConnection _conn;

        public DAL()
        {
            //Caminho da base de dados
            string path = HttpContext.Current.Server.MapPath("~/BaseDados/Toponimia.mdb");
            _conn = new OleDbConnection
                ("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + path + ";");
        }

        #region CREATE
        public bool InserirArruamento(Arruamento a)
        {
            try
            {
                if (_conn.State != ConnectionState.Open)
                    _conn.Open();

                OleDbCommand cmd = new OleDbCommand("INSERT INTO Arruamento (" +
                    CamposTabelas.TbArruamento +
                    ") VALUES (@p1,@p2,@p3,@p4,@p5,@p6,@p7,@p8)", _conn);

                cmd.Parameters.AddWithValue("@p1", a.Designacao);
                cmd.Parameters.AddWithValue("@p2", a.TipoArruamento.Id);
                cmd.Parameters.AddWithValue("@p3", a.Freguesia.Id);
                //Estas duas linhas garantem que, não sendo dado um objecto para início ou fim
                //de arruamento, é lá colocado o valor -1
                cmd.Parameters.AddWithValue("@p4", a.Inicio != null ? a.Inicio.Id : -1);
                cmd.Parameters.AddWithValue("@p5", a.Fim != null ? a.Fim.Id : -1);
                cmd.Parameters.AddWithValue("@p6", a.Extensao);
                cmd.Parameters.AddWithValue("@p7", a.Longitude);
                cmd.Parameters.AddWithValue("@p8", a.Latitude);

                if (cmd.ExecuteNonQuery() != 0)
                {
                    _conn.Close();
                    //chamada ao log para guardar a informação
                    InserirLog(LogType.INFO, "Arruamento inserido com sucesso");
                    return true;
                }
                else
                {
                    //atira uma excepção para ser apanhada no próximo catch
                    throw new Exception("Erro ao inserir Arruamento");
                }
            }
            catch (Exception ex)
            {
                //chamada ao log para guardar o erro
                InserirLog(LogType.ERROR, ex.Message);
                return false;
            }
        }
        public bool InserirTipoArruamento(TipoArrumento a)
        {
            try
            {
                if (_conn.State != ConnectionState.Open)
                    _conn.Open();

                OleDbCommand cmd = new OleDbCommand("INSERT INTO TipoArruamento (" +
                    CamposTabelas.TbTipoArruamento +
                    ") VALUES (@p1)", _conn);

                cmd.Parameters.AddWithValue("@p1", a.Designacao);

                if (cmd.ExecuteNonQuery() != 0)
                {
                    _conn.Close();
                    InserirLog(LogType.INFO, "TipoArruamento inserido com sucesso");
                    return true;
                }
                else
                {
                    throw new Exception("Erro ao inserir TipoArruamento");
                }
            }
            catch (Exception ex)
            {
                InserirLog(LogType.ERROR, ex.Message);
                return false;
            }
        }
        public bool InserirDistrito(Distrito a)
        {
            try
            {
                if (_conn.State != ConnectionState.Open)
                    _conn.Open();

                OleDbCommand cmd = new OleDbCommand("INSERT INTO Distrito (" +
                    CamposTabelas.TbDistrito +
                    ") VALUES (@p1)", _conn);

                cmd.Parameters.AddWithValue("@p1", a.Designacao);

                if (cmd.ExecuteNonQuery() != 0)
                {
                    _conn.Close();
                    InserirLog(LogType.INFO, "Distrito inserido com sucesso");
                    return true;
                }
                else
                {
                    throw new Exception("Erro ao inserir Distrito");
                }
            }
            catch (Exception ex)
            {
                InserirLog(LogType.ERROR, ex.Message);
                return false;
            }
        }
        public bool InserirConcelho(Concelho a)
        {
            try
            {
                if (_conn.State != ConnectionState.Open)
                    _conn.Open();

                OleDbCommand cmd = new OleDbCommand("INSERT INTO Concelho (" +
                    CamposTabelas.TbConcelho +
                    ") VALUES (@p1,@p2)", _conn);

                cmd.Parameters.AddWithValue("@p1", a.Designacao);
                cmd.Parameters.AddWithValue("@p2", a.Distrito.Id);

                if (cmd.ExecuteNonQuery() != 0)
                {
                    _conn.Close();
                    InserirLog(LogType.INFO, "Concelho inserido com sucesso");
                    return true;
                }
                else
                {
                    throw new Exception("Erro ao inserir Concelho");
                }
            }
            catch (Exception ex)
            {
                InserirLog(LogType.ERROR, ex.Message);
                return false;
            }
        }
        public bool InserirFreguesia(Freguesia a)
        {
            try
            {
                if (_conn.State != ConnectionState.Open)
                    _conn.Open();

                OleDbCommand cmd = new OleDbCommand("INSERT INTO Freguesia (" +
                    CamposTabelas.TbFreguesia +
                    ") VALUES (@p1,@p2)", _conn);

                cmd.Parameters.AddWithValue("@p1", a.Designacao);
                cmd.Parameters.AddWithValue("@p2", a.Concelho.Id);

                if (cmd.ExecuteNonQuery() != 0)
                {
                    _conn.Close();
                    InserirLog(LogType.INFO, "Freguesia inserida com sucesso");
                    return true;
                }
                else
                {
                    throw new Exception("Erro ao inserir Freguesia");
                }
            }
            catch (Exception ex)
            {
                InserirLog(LogType.ERROR, ex.Message);
                return false;
            }
        }
        public void InserirLog(LogType tipo, string mensagem)
        {
            try
            {
                if (_conn.State != ConnectionState.Open)
                    _conn.Open();

                OleDbCommand cmd = new OleDbCommand("INSERT INTO Log (" +
                    CamposTabelas.TbLog +
                    ") VALUES (@p1,@p2)", _conn);

                cmd.Parameters.AddWithValue("@p1", Enum.GetName(typeof(LogType), tipo));
                cmd.Parameters.AddWithValue("@p2", mensagem);

                cmd.ExecuteNonQuery();
                _conn.Close();
            }
            catch (Exception ex)
            {
                //aqui não se guarda no log porque como este método é o guardarlog, 
                //se não for possível fazê-lo, cai em ciclo infinito de exceptions
                _conn.Close();
            }
        }
        #endregion

        #region READ
        public bool UtilizadorValido(Utilizador u)
        {
            try
            {
                if (_conn.State != ConnectionState.Open)
                    _conn.Open();

                OleDbCommand cmd =
                    new OleDbCommand("SELECT id,nome,pass FROM Utilizadores WHERE nome=@nome AND pass=@pass", _conn);
                cmd.Parameters.AddWithValue("@nome", u.nome);
                cmd.Parameters.AddWithValue("@pass", u.pass);

                OleDbDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                _conn.Close();
            }
        }

        public List<Distrito> ObterDistritos()
        {
            try
            {
                if (_conn.State != ConnectionState.Open)
                    _conn.Open();

                OleDbCommand cmd = new OleDbCommand("SELECT Id," +
                    CamposTabelas.TbDistrito + " FROM Distrito", _conn);

                OleDbDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    List<Distrito> lista = new List<Distrito>();
                    while (dr.Read())
                    {
                        Distrito d = new Distrito();
                        d.Id = dr.GetInt32(0);
                        d.Designacao = dr.GetString(1);

                        lista.Add(d);
                    }
                    _conn.Close();
                    return lista;
                }
                else
                    throw new Exception("Erro ao obter Distritos");
            }
            catch (Exception ex)
            {
                _conn.Close();
                InserirLog(LogType.ERROR, ex.Message);

                return null;
            }
        }
        public List<Concelho> ObterConcelhos()
        {
            try
            {
                if (_conn.State != ConnectionState.Open)
                    _conn.Open();

                OleDbCommand cmd = new OleDbCommand("SELECT Id," +
                    CamposTabelas.TbConcelho + " FROM Concelho", _conn);

                OleDbDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    List<Concelho> lista = new List<Concelho>();
                    while (dr.Read())
                    {
                        Concelho d = new Concelho();
                        d.Id = dr.GetInt32(0);
                        d.Designacao = dr.GetString(1);
                        //notar que, como na base de dados apenas lemos o id do distrito,
                        //apenas podemos instanciar o objecto Distrito com o id.
                        //Para acrescentar a designacao, apenas se pode fazê-lo depois de terminar
                        //a leitura dos dados (depois do _conn.Close();)
                        d.Distrito = new Distrito();
                        d.Distrito.Id = dr.GetInt32(2);

                        lista.Add(d);
                    }
                    _conn.Close();
                    //Aqui vamos ler cada objecto da lista e, para cada um, pedir um novo objecto Distrito
                    //com os valores todos preenchidos (faltava a designacao)
                    foreach (Concelho conc in lista)
                        conc.Distrito = ObterDistritoById(conc.Distrito.Id);
                    return lista;
                }
                else
                    throw new Exception("Erro ao obter Concelhos");
            }
            catch (Exception ex)
            {
                _conn.Close();
                InserirLog(LogType.ERROR, ex.Message);

                return null;
            }
        }
        public List<Concelho> ObterConcelhosByDistrito(int id)
        {
            try
            {
                if (_conn.State != ConnectionState.Open)
                    _conn.Open();

                OleDbCommand cmd = new OleDbCommand("SELECT Id," +
                    CamposTabelas.TbConcelho + " FROM Concelho WHERE Distrito=@id", _conn);

                cmd.Parameters.AddWithValue("@id", id);
                OleDbDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    List<Concelho> lista = new List<Concelho>();
                    while (dr.Read())
                    {
                        Concelho d = new Concelho();
                        d.Id = dr.GetInt32(0);
                        d.Designacao = dr.GetString(1);
                        d.Distrito = new Distrito();
                        d.Distrito.Id = dr.GetInt32(2);

                        lista.Add(d);
                    }
                    _conn.Close();
                    foreach (Concelho conc in lista)
                        conc.Distrito = ObterDistritoById(conc.Distrito.Id);
                    return lista;
                }
                else
                    throw new Exception("Erro ao obter Concelhos");
            }
            catch (Exception ex)
            {
                _conn.Close();
                InserirLog(LogType.ERROR, ex.Message);

                return null;
            }
        }
        public List<Freguesia> ObterFreguesias()
        {
            try
            {
                if (_conn.State != ConnectionState.Open)
                    _conn.Open();

                OleDbCommand cmd = new OleDbCommand("SELECT Id," +
                    CamposTabelas.TbFreguesia + " FROM Freguesia", _conn);

                OleDbDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    List<Freguesia> lista = new List<Freguesia>();
                    while (dr.Read())
                    {
                        Freguesia d = new Freguesia();
                        d.Id = dr.GetInt32(0);
                        d.Designacao = dr.GetString(1);
                        d.Concelho = new Concelho();
                        d.Concelho.Id = dr.GetInt32(2);

                        lista.Add(d);
                    }
                    _conn.Close();
                    foreach (Freguesia freg in lista)
                        freg.Concelho = ObterConcelhoById(freg.Concelho.Id);
                    return lista;
                }
                else
                    throw new Exception("Erro ao obter Freguesias");
            }
            catch (Exception ex)
            {
                _conn.Close();
                InserirLog(LogType.ERROR, ex.Message);

                return null;
            }
        }
        public List<Freguesia> ObterFreguesiasByConcelho(int id)
        {
            try
            {
                if (_conn.State != ConnectionState.Open)
                    _conn.Open();

                OleDbCommand cmd = new OleDbCommand("SELECT Id," +
                    CamposTabelas.TbFreguesia + " FROM Freguesia WHERE Concelho=@id", _conn);

                cmd.Parameters.AddWithValue("@id", id);
                OleDbDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    List<Freguesia> lista = new List<Freguesia>();
                    while (dr.Read())
                    {
                        Freguesia d = new Freguesia();
                        d.Id = dr.GetInt32(0);
                        d.Designacao = dr.GetString(1);
                        d.Concelho = new Concelho();
                        d.Concelho.Id = dr.GetInt32(2);

                        lista.Add(d);
                    }
                    _conn.Close();
                    foreach (Freguesia freg in lista)
                        freg.Concelho = ObterConcelhoById(freg.Concelho.Id);
                    return lista;
                }
                else
                    throw new Exception("Erro ao obter Freguesias");
            }
            catch (Exception ex)
            {
                _conn.Close();
                InserirLog(LogType.ERROR, ex.Message);

                return null;
            }
        }
        public List<TipoArrumento> ObterTpArruamentos()
        {
            try
            {
                if (_conn.State != ConnectionState.Open)
                    _conn.Open();

                OleDbCommand cmd = new OleDbCommand("SELECT Id," +
                    CamposTabelas.TbTipoArruamento + " FROM TipoArruamento", _conn);

                OleDbDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    List<TipoArrumento> lista = new List<TipoArrumento>();
                    while (dr.Read())
                    {
                        TipoArrumento d = new TipoArrumento();
                        d.Id = dr.GetInt32(0);
                        d.Designacao = dr.GetString(1);

                        lista.Add(d);
                    }
                    _conn.Close();
                    return lista;
                }
                else
                    throw new Exception("Erro ao obter TipoArruamento");
            }
            catch (Exception ex)
            {
                _conn.Close();
                InserirLog(LogType.ERROR, ex.Message);

                return null;
            }
        }
        public List<Arruamento> ObterArruamentos()
        {
            try
            {
                if (_conn.State != ConnectionState.Open)
                    _conn.Open();

                OleDbCommand cmd = new OleDbCommand("SELECT Id," +
                    CamposTabelas.TbArruamento + " FROM Arruamento", _conn);

                OleDbDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    List<Arruamento> lista = new List<Arruamento>();
                    while (dr.Read())
                    {
                        Arruamento d = new Arruamento();
                        d.Id = dr.GetInt32(0);
                        d.Designacao = dr.GetString(1);
                        d.TipoArruamento = new TipoArrumento();
                        d.TipoArruamento.Id = dr.GetInt32(2);
                        d.Freguesia = new Freguesia();
                        d.Freguesia.Id = dr.GetInt32(3);
                        d.Inicio = new Arruamento();
                        d.Inicio.Id = dr.GetInt32(4);
                        d.Fim = new Arruamento();
                        d.Fim.Id = dr.GetInt32(5);
                        d.Extensao = (double)dr.GetDecimal(6);
                        d.Longitude = dr.GetString(7);
                        d.Latitude = dr.GetString(8);

                        lista.Add(d);
                    }
                    _conn.Close();
                    //Aqui vamos ler cada objecto da lista e, para cada um, pedir um novo 
                    //objecto com os valores todos preenchidos
                    //No caso do tipoarruamento faltava a designacao,
                    //No caso da freguesia faltava a designacao e o concelho,
                    //No caso do inicio faltava a designacao,
                    //No caso do fim faltava a designacao,
                    foreach (Arruamento arr in lista)
                    {
                        arr.TipoArruamento = ObterTipoArrumentoById(arr.TipoArruamento.Id);
                        arr.Freguesia = ObterFreguesiaById(arr.Freguesia.Id);
                        arr.Inicio = ObterArruamentoById(arr.Inicio.Id);
                        arr.Fim = ObterArruamentoById(arr.Fim.Id);
                    }

                    return lista;
                }
                else
                    throw new Exception("Erro ao obter Arruamentos");
            }
            catch (Exception ex)
            {
                _conn.Close();
                InserirLog(LogType.ERROR, ex.Message);
                return null;
            }
        }
        public List<Arruamento> ObterArruamentosByFreguesia(int id)
        {
            try
            {
                if (_conn.State != ConnectionState.Open)
                    _conn.Open();

                OleDbCommand cmd = new OleDbCommand("SELECT Id," +
                    CamposTabelas.TbArruamento + " FROM Arruamento WHERE Freguesia=@id", _conn);
                cmd.Parameters.AddWithValue("@id", id);

                OleDbDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    List<Arruamento> lista = new List<Arruamento>();
                    while (dr.Read())
                    {
                        Arruamento d = new Arruamento();
                        d.Id = dr.GetInt32(0);
                        d.Designacao = dr.GetString(1);
                        d.TipoArruamento = new TipoArrumento();
                        d.TipoArruamento.Id = dr.GetInt32(2);
                        d.Freguesia = new Freguesia();
                        d.Freguesia.Id = dr.GetInt32(3);
                        d.Inicio = new Arruamento();
                        d.Inicio.Id = dr.GetInt32(4);
                        d.Fim = new Arruamento();
                        d.Fim.Id = dr.GetInt32(5);
                        d.Extensao = (double)dr.GetDecimal(6);
                        d.Longitude = dr.GetString(7);
                        d.Latitude = dr.GetString(8);

                        lista.Add(d);
                    }
                    _conn.Close();
                    //Aqui vamos ler cada objecto da lista e, para cada um, pedir um novo 
                    //objecto com os valores todos preenchidos
                    //No caso do tipoarruamento faltava a designacao,
                    //No caso da freguesia faltava a designacao e o concelho,
                    //No caso do inicio faltava a designacao,
                    //No caso do fim faltava a designacao,
                    foreach (Arruamento arr in lista)
                    {
                        arr.TipoArruamento = ObterTipoArrumentoById(arr.TipoArruamento.Id);
                        arr.Freguesia = ObterFreguesiaById(arr.Freguesia.Id);
                        arr.Inicio = ObterArruamentoById(arr.Inicio.Id);
                        arr.Fim = ObterArruamentoById(arr.Fim.Id);
                    }

                    return lista;
                }
                else
                    throw new Exception("Erro ao obter Arruamentos");
            }
            catch (Exception ex)
            {
                _conn.Close();
                InserirLog(LogType.ERROR, ex.Message);
                return null;
            }
        }
        public List<Log> ObterLogs()
        {
            try
            {
                if (_conn.State != ConnectionState.Open)
                    _conn.Open();

                OleDbCommand cmd = new OleDbCommand("SELECT Id," +
                    CamposTabelas.TbLog + " FROM Log", _conn);

                OleDbDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    List<Log> lista = new List<Log>();
                    while (dr.Read())
                    {
                        Log d = new Log();
                        d.Id = dr.GetInt32(0);
                        d.Tipo = dr.GetString(1);
                        d.Mensagem = dr.GetString(2);

                        lista.Add(d);
                    }
                    _conn.Close();
                    return lista;
                }
                else { _conn.Close(); return null; }
            }
            catch (Exception ex)
            {
                _conn.Close();
                return null;
            }
        }

        public Distrito ObterDistritoById(int id)
        {
            try
            {
                if (_conn.State != ConnectionState.Open)
                    _conn.Open();

                OleDbCommand cmd = new OleDbCommand("SELECT Id," +
                    CamposTabelas.TbDistrito + " FROM Distrito WHERE Id=@id", _conn);
                cmd.Parameters.AddWithValue("@id", id);

                OleDbDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    Distrito d = new Distrito();
                    d.Id = dr.GetInt32(0);
                    d.Designacao = dr.GetString(1);
                    _conn.Close();
                    return d;
                }
                else
                    throw new Exception("Erro ao obter Distrito by Id: " + id);
            }
            catch (Exception ex)
            {
                _conn.Close();
                InserirLog(LogType.ERROR, ex.Message);
                return null;
            }
        }
        public Concelho ObterConcelhoById(int id)
        {
            try
            {
                if (_conn.State != ConnectionState.Open)
                    _conn.Open();

                OleDbCommand cmd = new OleDbCommand("SELECT Id," +
                    CamposTabelas.TbConcelho + " FROM Concelho WHERE Id=@id", _conn);
                cmd.Parameters.AddWithValue("@id", id);

                OleDbDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    Concelho d = new Concelho();
                    d.Id = dr.GetInt32(0);
                    d.Designacao = dr.GetString(1);
                    int idDistrito = dr.GetInt32(2);
                    _conn.Close();
                    d.Distrito = ObterDistritoById(idDistrito);
                    return d;
                }
                else
                    throw new Exception("Erro ao obter Concelho by Id: " + id);
            }
            catch (Exception ex)
            {
                _conn.Close();
                InserirLog(LogType.ERROR, ex.Message);
                return null;
            }
        }
        public Freguesia ObterFreguesiaById(int id)
        {
            try
            {
                if (_conn.State != ConnectionState.Open)
                    _conn.Open();

                OleDbCommand cmd = new OleDbCommand("SELECT Id," +
                    CamposTabelas.TbFreguesia + " FROM Freguesia WHERE Id=@id", _conn);
                cmd.Parameters.AddWithValue("@id", id);

                OleDbDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    Freguesia d = new Freguesia();
                    d.Id = dr.GetInt32(0);
                    d.Designacao = dr.GetString(1);
                    int idConcelho = dr.GetInt32(2);
                    _conn.Close();
                    d.Concelho = ObterConcelhoById(idConcelho);
                    return d;
                }
                else
                    throw new Exception("Erro ao obter Freguesia by Id: " + id);
            }
            catch (Exception ex)
            {
                _conn.Close();
                InserirLog(LogType.ERROR, ex.Message);
                return null;
            }
        }
        public TipoArrumento ObterTipoArrumentoById(int id)
        {
            try
            {
                if (_conn.State != ConnectionState.Open)
                    _conn.Open();

                OleDbCommand cmd = new OleDbCommand("SELECT Id," +
                    CamposTabelas.TbTipoArruamento + " FROM TipoArruamento WHERE Id=@id", _conn);
                cmd.Parameters.AddWithValue("@id", id);

                OleDbDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    TipoArrumento d = new TipoArrumento();
                    d.Id = dr.GetInt32(0);
                    d.Designacao = dr.GetString(1);
                    _conn.Close();
                    return d;
                }
                else
                    throw new Exception("Erro ao obter TipoArruamento by Id: " + id);
            }
            catch (Exception ex)
            {
                _conn.Close();
                InserirLog(LogType.ERROR, ex.Message);
                return null;
            }
        }
        public Arruamento ObterArruamentoById(int id)
        {
            if (id == -1)
                return new Arruamento()
                {
                    Id = -1,
                    Designacao = "Sem designação",
                    TipoArruamento = new TipoArrumento() { Id = -1, Designacao = "Sem designação" },
                    Freguesia = new Freguesia() { Id = -1, Designacao = "Sem designação" },
                    Inicio = new Arruamento() { Id = -1, Designacao = "Sem designação" },
                    Fim = new Arruamento() { Id = -1, Designacao = "Sem designação" }
                };

            try
            {
                if (_conn.State != ConnectionState.Open)
                    _conn.Open();

                OleDbCommand cmd = new OleDbCommand("SELECT Id," +
                    CamposTabelas.TbArruamento + " FROM Arruamento WHERE Id=@id", _conn);
                cmd.Parameters.AddWithValue("@id", id);

                OleDbDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    Arruamento d = new Arruamento();
                    d.Id = dr.GetInt32(0);
                    d.Designacao = dr.GetString(1);
                    int idTpArruamento = dr.GetInt32(2);
                    int idFreguesia = dr.GetInt32(3);
                    int idInicio = dr.GetInt32(4);
                    int idFim = dr.GetInt32(5);
                    d.Extensao = (double)dr.GetDecimal(6);
                    d.Longitude = dr.GetString(7);
                    d.Latitude = dr.GetString(8);
                    _conn.Close();
                    d.TipoArruamento = ObterTipoArrumentoById(idTpArruamento);
                    d.Freguesia = ObterFreguesiaById(idFreguesia);
                    d.Inicio = idInicio == -1 ? new Arruamento()
                    {
                        Id = -1,
                        Designacao = "Sem designação",
                        TipoArruamento = new TipoArrumento() { Id = -1, Designacao = "Sem designação" },
                        Freguesia = new Freguesia() { Id = -1, Designacao = "Sem designação" },
                        Inicio = new Arruamento() { Id = -1, Designacao = "Sem designação" },
                        Fim = new Arruamento() { Id = -1, Designacao = "Sem designação" }
                    }
                        : ObterArruamentoByIdSingle(idInicio);
                    d.Fim = idFim == -1 ? new Arruamento()
                    {
                        Id = -1,
                        Designacao = "Sem designação",
                        TipoArruamento = new TipoArrumento() { Id = -1, Designacao = "Sem designação" },
                        Freguesia = new Freguesia() { Id = -1, Designacao = "Sem designação" },
                        Inicio = new Arruamento() { Id = -1, Designacao = "Sem designação" },
                        Fim = new Arruamento() { Id = -1, Designacao = "Sem designação" }
                    } : ObterArruamentoByIdSingle(idFim);
                    return d;
                }
                else
                    throw new Exception("Erro ao obter Arruamento by Id: " + id);
            }
            catch (Exception ex)
            {
                _conn.Close();
                InserirLog(LogType.ERROR, ex.Message);
                return null;
            }
        }
        public Arruamento ObterArruamentoByIdSingle(int id)
        {
            if (id == -1)
                return new Arruamento()
                {
                    Id = -1,
                    Designacao = "Sem designação",
                    TipoArruamento = new TipoArrumento() { Id = -1, Designacao = "Sem designação" },
                    Freguesia = new Freguesia() { Id = -1, Designacao = "Sem designação" },
                    Inicio = new Arruamento() { Id = -1, Designacao = "Sem designação" },
                    Fim = new Arruamento() { Id = -1, Designacao = "Sem designação" }
                };

            try
            {
                if (_conn.State != ConnectionState.Open)
                    _conn.Open();

                OleDbCommand cmd = new OleDbCommand("SELECT Id," +
                    CamposTabelas.TbArruamento + " FROM Arruamento WHERE Id=@id", _conn);
                cmd.Parameters.AddWithValue("@id", id);

                OleDbDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    Arruamento d = new Arruamento();
                    d.Id = dr.GetInt32(0);
                    d.Designacao = dr.GetString(1);
                    _conn.Close();
                    return d;
                }
                else
                    throw new Exception("Erro ao obter Arruamento by Id: " + id + " Single");
            }
            catch (Exception ex)
            {
                _conn.Close();
                InserirLog(LogType.ERROR, ex.Message);
                return null;
            }
        }
        #endregion

        #region UPDATE

        #endregion

        #region DELETE

        #endregion


    }
}