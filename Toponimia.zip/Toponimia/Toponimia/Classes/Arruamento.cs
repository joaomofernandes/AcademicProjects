﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Toponimia.Classes
{
    public class Arruamento
    {
        public int Id { get; set; }
        public string Designacao { get; set; }
        public TipoArrumento TipoArruamento { get; set; }
        public Freguesia Freguesia { get; set; }
        public Arruamento Inicio { get; set; }
        public Arruamento Fim { get; set; }
        public double Extensao { get; set; }
        public string Longitude { get; set; }
        public string Latitude { get; set; }
    }
}