﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Toponimia
{
    public partial class ConsumirWebServices : System.Web.UI.Page
    {
        protected  void Page_Load(object sender, EventArgs e)
        {
            WSTestes.WebServiceTesteSoapClient a =
                new WSTestes.WebServiceTesteSoapClient();
        }

        private async void Teste()
        {
            WSTestes.WebServiceTesteSoapClient myService =
                new WSTestes.WebServiceTesteSoapClient();

            int y = await myService.ObterInteiroAsync();
        }
    }
}