﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Toponimia
{
    public partial class TesteWS : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //WebService1 x = new WebService1();

            //Alvo.Text = x.ObterNomeDistritoById(1);

            //WSExterno.WebServiceTesteSoapClient y =
            //    new WSExterno.WebServiceTesteSoapClient();

            //Alvo.Text = y.ObterUtilizadorTestes(99).Name;
        }
    }
}